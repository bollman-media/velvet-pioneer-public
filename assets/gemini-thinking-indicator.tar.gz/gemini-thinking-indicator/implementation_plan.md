# Cross-Platform Thinking Indicator — Complete Implementation Plan

## Context for Next Conversation

This plan was created in conversation `afb1819a-9ffa-4c52-b422-bcdce104867d`. The next conversation will have **zero context** — this document is the only handoff artifact. Everything needed to execute is here.

### What This Is

A **production-ready, reusable animated loading indicator** for the Gemini App. It renders N dots that animate through 4 motion states. It must be implemented natively on **Web (Angular)**, **iOS (SwiftUI)**, and **Android (Jetpack Compose)** — all looking identical.

### What's In This Package

```
gemini-thinking-indicator/
├── implementation_plan.md        ← THIS FILE (the instructions)
├── prototype/                    ← Original React tuner prototype (source of truth for visual feel)
│   ├── src/
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   ├── styles.css
│   │   └── components/
│   │       ├── ThinkingIndicator.jsx   ← THE CORE ANIMATION LOGIC TO PORT
│   │       ├── ControlsPanel.jsx
│   │       ├── EaseGraph.jsx
│   │       ├── MobileFrame.jsx
│   │       └── TextRenderer.jsx
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── postcss.config.js
├── web/thinking-indicator/       ← TO BE CREATED: Angular component
├── ios/ThinkingIndicator/        ← TO BE CREATED: Swift package
└── android/thinking-indicator/   ← TO BE CREATED: Kotlin files
```

### How to Run the Prototype

```bash
cd prototype/
npm install
npm run dev
```

Opens at `http://localhost:5173`. The controls panel on the right lets you tune all animation parameters. The `ThinkingIndicator.jsx` file contains ALL the math that must be ported.

---

## Decisions Made (Open Questions Resolved)

| Question | Decision |
|----------|----------|
| State naming | **Human-readable**: `idle`, `wave`, `triangulate`, `juggle` |
| States to ship | **4 core only** (no Technical/Snake) |
| Dark mode | **`dotColor` as input parameter** — eng controls color |
| Accessibility | **Yes** — bake in default label "Thinking" per platform |
| Size | **`dotSize` + `dotSpacing` exposed as parameters** with current defaults |
| Unused params | **Strip all prototype-only parameters** from production API |

> [!IMPORTANT]
> **"Spinner" has been renamed to "Triangulate"** across all platforms.

---

## Production API (All Platforms)

The production component has a **simple, clean API**. All per-state animation details are baked into internal presets — NOT exposed to the consumer.

### Public Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `state` | enum | `idle` | One of: `idle`, `wave`, `triangulate`, `juggle` |
| `dotCount` | int | `3` | Number of dots |
| `dotSize` | float | `4` | Dot diameter (dp/pt/px) |
| `dotSpacing` | float | `3` | Gap between dots |
| `dotColor` | color | `#000000` | Dot fill color |
| `speed` | float | `0.6` | Global animation speed |
| `transitionDuration` | int | `1000` | State transition time (ms) |
| `accessibilityLabel` | string | `"Thinking"` | Screen reader announcement |
| `textStyleOption` | enum | `TLDR` | Text style preset: `TLDR` or `DisplayS` |

### Text Styles

The component supports two text styles for streaming text:

**1. LR26/TLDR**
- Font: "Google Sans Flex"
- Size: 24px
- Weight: 380
- Line Height: 28px
- Alignment: Follows `textAlignment` prop

**2. LR26/Display S**
- Font: "Google Sans Flex"
- Size: 32px
- Weight: 360
- Line Height: 38px
- Alignment: Center (forced)

### Internal Presets (Baked In, Not Exposed)

These are the tuned values from the prototype. They live inside each platform's math file as constants:

```json
{
  "idle": {
    "waveHeight": 0, "dotDelay": 0, "opacity": 0.85
  },
  "wave": {
    "waveHeight": 2.5, "dotDelay": 1.05, "opacity": 1.0,
    "frequencyMultiplier": 0.005
  },
  "triangulate": {
    "spinSpeed": 0.8, "minRadius": 3, "maxRadius": 7,
    "yOffset": -5, "opacity": 1.0,
    "frequencyMultiplier": 0.003, "dotDelay": 1.05
  },
  "juggle": {
    "radius": 7, "yOffset": -6, "opacity": 1.0,
    "frequencyMultiplier": 0.003, "dotDelay": 1.05
  }
}
```

### Easing Curve (Baked In)

```
cubic-bezier(0.565, 0.005, 0.425, 0.995)
```

Appear duration: 750ms, disappear duration: 500ms, dot fade stagger: 0.05s.

---

## The Math to Port

The file `prototype/src/components/ThinkingIndicator.jsx` contains everything. Here is the exact math for each state, written as platform-agnostic pseudocode.

### Shared Setup (all states)

```
totalWidth = dotCount * dotSize + (dotCount - 1) * dotSpacing
initialX = i * (dotSize + dotSpacing) + dotSize / 2
centerOffsetX = totalWidth / 2 - initialX
effectiveSpeed = speed
```

### State: Idle

```
x = 0
y = 0
```

### State: Wave

```
frequency = 0.005 * effectiveSpeed
phase = t * frequency - i * dotDelay        // dotDelay = 1.05
y = (sin(phase) - 1) * waveHeight           // waveHeight = 2.5
x = 0
```

- `t` = time in milliseconds from platform timer
- `i` = dot index (0-based)
- The `- 1` keeps dots oscillating between `-2*waveHeight` and `0` (at or above rest)

### State: Triangulate (formerly "Spinner")

```
frequency = 0.003 * effectiveSpeed * spinSpeed    // spinSpeed = 0.8
theta = t * frequency + i * (2π / dotCount)

minR = 3, maxR = 7
baseRadius = (minR + maxR) / 2                    // = 5
amplitude = (maxR - minR) / 2                     // = 2

r = baseRadius + amplitude * cos(dotCount * theta)
scaleFactor = 1 + 0.2 * sin(t * 0.002)
finalR = r * scaleFactor

x = centerOffsetX + finalR * cos(theta)
y = yOffset + finalR * sin(theta)                 // yOffset = -5
```

This creates a rose-curve (flower petal) orbit pattern.

### State: Juggle

```
frequency = 0.003 * effectiveSpeed
theta = t * frequency + i * (2π / dotCount)

x = centerOffsetX + radius * cos(theta)           // radius = 7
y = yOffset + (radius * 2/3) * sin(2 * theta)     // yOffset = -6
```

This creates a figure-8 (lemniscate) path via `sin(2θ)`.

### State Transitions (Momentum Preservation)

When state changes, DON'T snap to new position. Smoothly interpolate:

```
On state change:
  transitionStartTime = now
  startX = currentX
  startY = currentY
  startDx = lastFrameDeltaX
  startDy = lastFrameDeltaY

Each frame during transition:
  progress = (now - transitionStartTime) / transitionDuration
  if progress >= 1: use new position directly, end transition
  else:
    easedProgress = cubicBezierEase(progress)
    framesElapsed = (now - transitionStartTime) / 16.6
    oldX = startX + startDx * framesElapsed    // linear extrapolation
    oldY = startY + startDy * framesElapsed
    finalX = oldX + (newX - oldX) * easedProgress
    finalY = oldY + (newY - oldY) * easedProgress
```

### Cubic Bezier Easing (Newton-Raphson)

```
function cubicBezierEase(t, x1=0.565, y1=0.005, x2=0.425, y2=0.995):
  guess = t
  for 5 iterations:
    cx = 3*(1-guess)²*guess*x1 + 3*(1-guess)*guess²*x2 + guess³
    dx = 3*(1-guess)²*x1 + 6*(1-guess)*guess*(x2-x1) + 3*guess²*(1-x2)
    if |dx| < 1e-6: break
    guess -= (cx - t) / dx
    guess = clamp(guess, 0, 1)
  return 3*(1-guess)²*guess*y1 + 3*(1-guess)*guess²*y2 + guess³
```

---

## Platform Implementation Details

### Web — Angular + Canvas + requestAnimationFrame

**File structure:**
```
web/thinking-indicator/
├── thinking-indicator.component.ts
├── animation-math.ts
├── types.ts
└── README.md
```

**Rendering**: Use `<canvas>` element with `requestAnimationFrame`. Each frame: clear canvas, compute positions via `getPointForState()`, draw circles with `ctx.arc()` + `ctx.fill()`.

**Component**: Angular standalone component with `@Input()` for each public parameter. Use `ngOnChanges` to detect state changes. Use `ngOnDestroy` to cancel animation frame. Use `ElementRef` + `ViewChild` to access canvas.

**Accessibility**: Set `role="img"` and `aria-label` on the canvas element.

### iOS — SwiftUI Canvas + CADisplayLink

**File structure:**
```
ios/ThinkingIndicator/
├── ThinkingIndicatorView.swift
├── AnimationEngine.swift
├── AnimationMath.swift
├── CubicBezier.swift
└── IndicatorState.swift
```

**Rendering**: SwiftUI `Canvas` view. `AnimationEngine` wraps `CADisplayLink` as an `ObservableObject` publishing frame timestamps. Each frame: compute positions, draw with `context.fill(Circle())`.

**Accessibility**: Set `.accessibilityLabel(accessibilityLabel)` and `.accessibilityAddTraits(.updatesFrequently)` on the view.

### Android — Jetpack Compose Canvas + withFrameMillis

**File structure:**
```
android/thinking-indicator/
├── ThinkingIndicator.kt
├── AnimationMath.kt
├── CubicBezier.kt
└── IndicatorState.kt
```

**Rendering**: Compose `Canvas` composable with `drawCircle()`. Animation loop via `LaunchedEffect(Unit) { while(true) { withFrameMillis { t -> ... } } }`. State changes detected via `snapshotFlow`.

**Accessibility**: Use `Modifier.semantics { contentDescription = accessibilityLabel }`.

---

## Live Tuner Architecture

The React prototype serves as a **live tuner**. To sync tuned values back to platform implementations:

1. Add an **"Export Presets"** button to the prototype's ControlsPanel
2. It writes a `presets.json` file with all baked-in values
3. Each platform's math file reads defaults from this JSON at build time (or a build script injects the values as constants)
4. This way: tune in prototype → export → rebuild platforms → values are synced

**Implementation**: Add a button that calls `JSON.stringify()` on the current state settings and triggers a file download. The downloaded JSON maps directly to the preset constants in each platform's math file.

---

## Execution Order

1. **Phase 1**: Create the `presets.json` export button in the prototype
2. **Phase 2**: Write `web/thinking-indicator/` (Angular + Canvas)
3. **Phase 3**: Write `ios/ThinkingIndicator/` (SwiftUI + CADisplayLink)
4. **Phase 4**: Write `android/thinking-indicator/` (Compose + withFrameMillis)
5. **Phase 5**: Test each platform, verify visual match against prototype
6. **Phase 6**: Write README.md with integration guides

---

## Key Constraints

- **No Rive** — not available in the Gemini App stack
- **No Lottie** — can't represent parametric/procedural math animations
- **No React Native** — Gemini App uses Angular + native Swift/Kotlin
- **No animation libraries** — pure platform-native code only
- **Zero external dependencies** — each platform's files are self-contained
- **ENG just imports files** — no build system changes, no package managers
