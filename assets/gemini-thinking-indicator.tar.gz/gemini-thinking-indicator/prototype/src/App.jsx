import React, { useState, useEffect, useRef, useCallback } from 'react';
import MobileFrame from './components/MobileFrame';
import TextRenderer from './components/TextRenderer';
import ThinkingIndicator from './components/ThinkingIndicator';
import ControlsPanel from './components/ControlsPanel';
import EaseGraph from './components/EaseGraph';

export default function App() {
  const [duration, setDuration] = useState(() => {
    const saved = localStorage.getItem('proto_duration');
    return saved !== null ? Number(saved) : 470;
  });
  const stateTimerRef = useRef(null);
  const textTimerRef = useRef(null);
  const fadeTimerRef = useRef(null);
  const [overlap, setOverlap] = useState(() => {
    const saved = localStorage.getItem('proto_overlap');
    return saved !== null ? Number(saved) : 30;
  });
  const [state, setState] = useState(() => {
    const saved = localStorage.getItem('proto_state');
    return saved !== null ? Number(saved) : 1;
  });
  const [baseSpeed, setBaseSpeed] = useState(() => {
    const saved = localStorage.getItem('proto_speed');
    return saved !== null ? Number(saved) : 0.6;
  });
  const [renderMode, setRenderMode] = useState(() => localStorage.getItem('proto_renderMode') || 'word');
  const [easing, setEasing] = useState(() => {
    const saved = localStorage.getItem('proto_easing');
    return saved !== null ? JSON.parse(saved) : [0.565, 0.0050000000000000044, 0.425, 0.995];
  });
  const [commaSeparatedTexts, setCommaSeparatedTexts] = useState(() => localStorage.getItem('proto_commaSeparatedTexts') || "Considering nearby routes, Searching for Awesome restaurants, Finding best deals");
  const [staticDuration, setStaticDuration] = useState(() => {
    const saved = localStorage.getItem('proto_staticDuration');
    return saved !== null ? Number(saved) : 3600;
  });
  const [indicatorPosition, setIndicatorPosition] = useState(() => localStorage.getItem('proto_indicatorPosition') || 'end');
  const [textAlignment, setTextAlignment] = useState(() => localStorage.getItem('proto_textAlignment') || 'center');
  const [textStyleOption, setTextStyleOption] = useState(() => localStorage.getItem('proto_textStyleOption') || 'TLDR');
  const [fadeIndicatorWithText, setFadeIndicatorWithText] = useState(() => {
    const saved = localStorage.getItem('proto_fadeIndicatorWithText');
    return saved !== null ? saved === 'true' : true;
  });
  const [currentTextIndex, setCurrentTextIndex] = useState(0);
  const [triggerKey, setTriggerKey] = useState(0);

  const [sidebarWidth, setSidebarWidth] = useState(380);

  const startResizing = (mouseDownEvent) => {
    let lastX = mouseDownEvent.clientX;
    const doDrag = (mouseMoveEvent) => {
      const delta = mouseMoveEvent.clientX - lastX;
      lastX = mouseMoveEvent.clientX;
      setSidebarWidth(w => Math.max(250, Math.min(600, w + delta)));
    };
    const stopDrag = () => {
      document.removeEventListener('mousemove', doDrag);
      document.removeEventListener('mouseup', stopDrag);
    };
    document.addEventListener('mousemove', doDrag);
    document.addEventListener('mouseup', stopDrag);
  };

  const textList = commaSeparatedTexts.split(',').map(t => t.trim()).filter(t => t.length > 0);
  const currentText = textList[currentTextIndex] || "";

  useEffect(() => {
    setCurrentTextIndex(0);
  }, [commaSeparatedTexts]);

  const [stateSettings, setStateSettings] = useState(() => {
    const saved = localStorage.getItem('proto_stateSettings');
    const defaults = {
      1: { dotCount: 3, spacing: 3, size: 4, timeout: 1000, noTimeout: false, targetStates: [2, 5, 6, 1], waveHeight: 2.5, dotDelay: 0.5, opacity: 0.85, dotFadeDelay: 0, speedMultiplier: 1 },
      2: { dotCount: 3, spacing: 3, size: 4, timeout: 1500, noTimeout: false, targetStates: [5, 1], waveHeight: 2.5, dotDelay: 1.05, opacity: 1, dotFadeDelay: 0, speedMultiplier: 1 },
      4: { dotCount: 6, spacing: 3, size: 4, timeout: 5000, noTimeout: false, targetStates: [1], waveHeight: 2, dotDelay: 1.05, opacity: 1, isDynamicDelay: true, dotDelayMin: 0.15, dotDelayMax: 1, delayCycleDuration: 4700, dotFadeDelay: 0.12, speedMultiplier: 1 },
      5: { dotCount: 3, spacing: 3, size: 4, timeout: 1500, noTimeout: false, targetStates: [6], waveHeight: 2.5, dotDelay: 1.05, opacity: 1, dotFadeDelay: 0.05, minRadius: 3, maxRadius: 7, spinSpeed: 0.8, yOffset: -5, radius: 5, speedMultiplier: 1 },
      6: { dotCount: 3, spacing: 3, size: 4, timeout: 1000, noTimeout: false, targetStates: [2], waveHeight: 2.5, dotDelay: 1.05, opacity: 1, dotFadeDelay: 0, radius: 7, yOffset: -6, speedMultiplier: 1 },
      7: { dotCount: 3, spacing: 3, size: 4, timeout: 5000, noTimeout: true, targetStates: [1], waveHeight: 4, dotDelay: 1.15, opacity: 1, dotFadeDelay: 0, speedMultiplier: 1.5 },
      10: { dotCount: 3, spacing: 3, size: 4, timeout: 5000, noTimeout: true, targetStates: [1], waveHeight: 2.5, dotDelay: 1.7, opacity: 1, dotFadeDelay: 0, speedMultiplier: 1.7, alternateRotation: true },
      11: { dotCount: 3, spacing: 3, size: 4, timeout: 1000, noTimeout: false, targetStates: [2], waveHeight: 2.5, dotDelay: 0.55, opacity: 1, dotFadeDelay: 0, yOffset: -6, pathWidth: 15, pathHeight: 9, speedMultiplier: 0.8, radius: 7 },
    };
    if (saved !== null) {
      try {
        const parsed = JSON.parse(saved);
        const migrate = (stateConf) => {
          if (stateConf && stateConf.targetState !== undefined && !stateConf.targetStates) {
            stateConf.targetStates = [stateConf.targetState];
            delete stateConf.targetState;
          }
          return stateConf;
        };
        return {
          1: { ...defaults[1], ...migrate(parsed[1]) },
          2: { ...defaults[2], ...migrate(parsed[2]) },
          4: { ...defaults[4], ...migrate(parsed[4]) },
          5: { ...defaults[5], ...migrate(parsed[5]) },
          6: { ...defaults[6], ...migrate(parsed[6]) },
          7: { ...defaults[7], ...migrate(parsed[7]) },
          10: { ...defaults[10], ...migrate(parsed[10]) },
          11: { ...defaults[11], ...migrate(parsed[11]) },
        };
      } catch (e) {
        return defaults;
      }
    }
    return defaults;
  });

  const [nextTargetIndices, setNextTargetIndices] = useState({ 1: 0, 2: 0, 4: 0, 5: 0, 6: 0 });
  const nextTargetIndicesRef = useRef(nextTargetIndices);
  useEffect(() => {
    nextTargetIndicesRef.current = nextTargetIndices;
  }, [nextTargetIndices]);

  const [dotColor, setDotColor] = useState(() => localStorage.getItem('proto_dotColor') || '#000000');
  const [isTextFadingOut, setIsTextFadingOut] = useState(false);
  const [showIndicatorOnlyAtEnd, setShowIndicatorOnlyAtEnd] = useState(() => {
    const saved = localStorage.getItem('proto_showIndicatorOnlyAtEnd');
    return saved !== null ? saved === 'true' : true;
  });
  const [transitionDuration, setTransitionDuration] = useState(() => {
    const saved = localStorage.getItem('proto_transitionDuration');
    return saved !== null ? Number(saved) : 1000;
  });
  const [appearDuration, setAppearDuration] = useState(() => {
    const saved = localStorage.getItem('proto_appearDuration');
    return saved !== null ? Number(saved) : 750;
  });
  const [disappearDuration, setDisappearDuration] = useState(() => {
    const saved = localStorage.getItem('proto_disappearDuration');
    return saved !== null ? Number(saved) : 500;
  });
  const [showWithoutText, setShowWithoutText] = useState(() => {
    const saved = localStorage.getItem('proto_showWithoutText');
    return saved !== null ? saved === 'true' : true;
  });
  const [manualStateOverride, setManualStateOverride] = useState(false);
  const [manualSelectedState, setManualSelectedState] = useState(null);
  const [copiedStateSettings, setCopiedStateSettings] = useState(null);
  const [isPaused, setIsPaused] = useState(false);
  const isPausedRef = useRef(isPaused);
  const [showDetailedControls, setShowDetailedControls] = useState(false);

  // Keep refs for values used inside timeouts
  const stateSettingsRef = useRef(stateSettings);
  useEffect(() => { stateSettingsRef.current = stateSettings; }, [stateSettings]);

  const manualStateOverrideRef = useRef(manualStateOverride);
  useEffect(() => { manualStateOverrideRef.current = manualStateOverride; }, [manualStateOverride]);

  const manualSelectedStateRef = useRef(manualSelectedState);
  useEffect(() => { manualSelectedStateRef.current = manualSelectedState; }, [manualSelectedState]);
  const stateRef = useRef(state);
  useEffect(() => { stateRef.current = state; }, [state]);
  const staticDurationRef = useRef(staticDuration);
  useEffect(() => { staticDurationRef.current = staticDuration; }, [staticDuration]);
  const textListRef = useRef(textList);
  useEffect(() => { textListRef.current = textList; }, [textList]);

  // ─── Clear ALL timers helper ───
  const clearAllTimers = useCallback(() => {
    if (stateTimerRef.current) { clearTimeout(stateTimerRef.current); stateTimerRef.current = null; }
    if (textTimerRef.current) { clearTimeout(textTimerRef.current); textTimerRef.current = null; }
    if (fadeTimerRef.current) { clearTimeout(fadeTimerRef.current); fadeTimerRef.current = null; }
  }, []);

  // ─── Advance target state using alternating indices ───
  const getNextTarget = useCallback((fromState) => {
    const settings = stateSettingsRef.current[fromState];
    if (!settings || !settings.targetStates || settings.targetStates.length === 0) return null;
    const currentIndex = nextTargetIndicesRef.current[fromState] || 0;
    const safeIndex = currentIndex % settings.targetStates.length;
    const target = settings.targetStates[safeIndex];
    setNextTargetIndices(prev => ({
      ...prev,
      [fromState]: (safeIndex + 1) % settings.targetStates.length
    }));
    return target;
  }, []);






  // ─── "Show Without Text" mode: start state loop when enabled ───
  useEffect(() => {
    if (showWithoutText && !isPaused) {
      setState(1);
      clearAllTimers();

      const interval = setInterval(() => {
        if (isPausedRef.current) return;
        
        const currentState = stateRef.current;
        const currentSettings = stateSettingsRef.current[currentState];
        let nextState = currentState;

        if (manualStateOverrideRef.current && manualSelectedStateRef.current !== null) {
          nextState = manualSelectedStateRef.current;
        } else if (currentSettings && currentSettings.targetStates && currentSettings.targetStates.length > 0) {
          nextState = getNextTarget(currentState);
        } else {
          nextState = 1;
        }

        setState(nextState);
      }, staticDuration);

      return () => clearInterval(interval);
    }
  }, [showWithoutText, isPaused, staticDuration, getNextTarget]);

  // ─── Persist all settings ───
  useEffect(() => {
    localStorage.setItem('proto_duration', duration);
    localStorage.setItem('proto_overlap', overlap);
    localStorage.setItem('proto_state', state);
    localStorage.setItem('proto_speed', baseSpeed);
    localStorage.setItem('proto_renderMode', renderMode);
    localStorage.setItem('proto_easing', JSON.stringify(easing));
    localStorage.setItem('proto_commaSeparatedTexts', commaSeparatedTexts);
    localStorage.setItem('proto_staticDuration', staticDuration);
    localStorage.setItem('proto_stateSettings', JSON.stringify(stateSettings));
    localStorage.setItem('proto_disappearDuration', disappearDuration);
    localStorage.setItem('proto_showWithoutText', showWithoutText);
    localStorage.setItem('proto_indicatorPosition', indicatorPosition);
    localStorage.setItem('proto_textAlignment', textAlignment);
    localStorage.setItem('proto_fadeIndicatorWithText', fadeIndicatorWithText);
    localStorage.setItem('proto_textStyleOption', textStyleOption);
  }, [duration, overlap, state, baseSpeed, renderMode, easing, commaSeparatedTexts, staticDuration, stateSettings, dotColor, showIndicatorOnlyAtEnd, transitionDuration, appearDuration, disappearDuration, showWithoutText, indicatorPosition, textAlignment, fadeIndicatorWithText, textStyleOption]);

  const [presets, setPresets] = useState([
    { name: "Default", duration: 300, overlap: 100, state: 1, speed: 1, easing: [0.25, 0.1, 0.25, 1.0] },
    { name: "Fast & Snappy", duration: 150, overlap: 50, state: 2, speed: 2, easing: [0.1, 0.9, 0.1, 1.0] },
  ]);

  const triggerAnimation = useCallback(() => {
    setTriggerKey(prev => prev + 1);
    // Don't reset state — let the state machine continue across text changes
    setIsTextFadingOut(false);
    clearAllTimers();
  }, [clearAllTimers]);

  // ─── Pause / Unpause ───
  useEffect(() => {
    isPausedRef.current = isPaused;
    if (isPaused) {
      clearAllTimers();
    } else {
      // When unpausing, restart the animation cycle
      triggerAnimation();
    }
  }, [isPaused, clearAllTimers, triggerAnimation]);

  const setManualState = (s) => {
    if (manualSelectedState === s) {
      setManualSelectedState(null);
      setManualStateOverride(false);
      setState(1); // Go back to idle if deselected
    } else {
      setManualSelectedState(s);
      setManualStateOverride(true);
      setState(s);
    }
  };

  // ─── Called by TextRenderer once text is 100% visible ───
  const handleTextComplete = useCallback(() => {
    if (isPausedRef.current) return;

    clearAllTimers();

    // After staticDuration, transition to next state AND advance text
    textTimerRef.current = setTimeout(() => {
      if (isPausedRef.current) return;

      const currentState = stateRef.current;
      const currentSettings = stateSettingsRef.current[currentState];
      let nextState = currentState;

      if (manualStateOverrideRef.current && manualSelectedStateRef.current !== null) {
        nextState = manualSelectedStateRef.current;
      } else if (currentSettings && currentSettings.targetStates && currentSettings.targetStates.length > 0) {
        nextState = getNextTarget(currentState);
      } else {
        nextState = 1; // Fallback to idle
      }

      // Fade out text AND dots together
      setIsTextFadingOut(true);

      // After fade-out completes, advance to next text and apply new state
      fadeTimerRef.current = setTimeout(() => {
        if (isPausedRef.current) return;
        setIsTextFadingOut(false);
        
        setState(nextState); // Apply new state HERE
        
        setCurrentTextIndex((prev) => (prev + 1) % textListRef.current.length);
        triggerAnimation();
      }, 500);
    }, staticDurationRef.current);
  }, [clearAllTimers, getNextTarget, triggerAnimation]);

  const copyStateSettings = () => {
    setCopiedStateSettings(stateSettings[state]);
  };

  const pasteStateSettings = () => {
    if (copiedStateSettings) {
      setStateSettings(prev => {
        const targetSettings = prev[state];
        const updatedSettings = { ...copiedStateSettings };

        // Retain dynamic delay settings if target has them
        if (targetSettings.isDynamicDelay !== undefined) updatedSettings.isDynamicDelay = targetSettings.isDynamicDelay;
        if (targetSettings.dotDelayMin !== undefined) updatedSettings.dotDelayMin = targetSettings.dotDelayMin;
        if (targetSettings.dotDelayMax !== undefined) updatedSettings.dotDelayMax = targetSettings.dotDelayMax;
        if (targetSettings.delayCycleDuration !== undefined) updatedSettings.delayCycleDuration = targetSettings.delayCycleDuration;

        return {
          ...prev,
          [state]: updatedSettings
        };
      });
    }
  };

  const exportConfiguration = () => {
    const config = {
      duration,
      overlap,
      state,
      speed: baseSpeed,
      renderMode,
      easing,
      commaSeparatedTexts,
      staticDuration,
      stateSettings,
      dotColor,
      showIndicatorOnlyAtEnd,
      transitionDuration,
      appearDuration,
      disappearDuration,
      showWithoutText,
      indicatorPosition,
      textAlignment
    };
    const jsonString = JSON.stringify(config, null, 2);
    navigator.clipboard.writeText(jsonString).then(() => {
      alert("Configuration copied to clipboard!");
    }).catch(err => {
      console.error('Failed to copy: ', err);
      alert("Failed to copy configuration to clipboard. See console for details.");
    });
  };

  const loadPreset = (preset) => {
    setDuration(preset.duration);
    setOverlap(preset.overlap);
    setState(preset.state);
    setBaseSpeed(preset.speed);
    setEasing(preset.easing);
    triggerAnimation();
  };

  const savePreset = (name) => {
    setPresets([...presets, { name, duration, overlap, state, speed: baseSpeed, easing }]);
  };

  const deletePreset = (name) => {
    setPresets(presets.filter(p => p.name !== name));
  };

  const easingString = `cubic-bezier(${easing[0]}, ${easing[1]}, ${easing[2]}, ${easing[3]})`;

  const currentStateSettings = stateSettings[state] || stateSettings[1];
  const state2 = stateSettings[2];
  const state2Width = state2.dotCount * state2.size + (state2.dotCount - 1) * state2.spacing;

  return (
    <div className="flex h-screen bg-gray-50 font-sans">
      {/* Sidebar: Controls */}
      <div style={{ width: sidebarWidth }} className="flex-shrink-0 bg-white shadow-lg z-10 flex flex-col">
        <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-white">
          <h2 className="text-lg font-semibold text-gray-900">Controls</h2>
          <button 
            onClick={() => setShowDetailedControls(!showDetailedControls)}
            className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium transition-colors"
          >
            {showDetailedControls ? 'Done' : 'Edit Animation'}
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <ControlsPanel 
            showDetailedControls={showDetailedControls}
            indicatorPosition={indicatorPosition} setIndicatorPosition={setIndicatorPosition}
            textAlignment={textAlignment} setTextAlignment={setTextAlignment}
            textStyleOption={textStyleOption} setTextStyleOption={setTextStyleOption}
            fadeIndicatorWithText={fadeIndicatorWithText} setFadeIndicatorWithText={setFadeIndicatorWithText}
            duration={duration} setDuration={setDuration}
            overlap={overlap} setOverlap={setOverlap}
            state={state} setState={setManualState}
            baseSpeed={baseSpeed} setBaseSpeed={setBaseSpeed}
            renderMode={renderMode} setRenderMode={setRenderMode}
            triggerAnimation={triggerAnimation}
            presets={presets} loadPreset={loadPreset} savePreset={savePreset} deletePreset={deletePreset}
            stateSettings={stateSettings} setStateSettings={setStateSettings}
            nextTargetIndices={nextTargetIndices}
            dotColor={dotColor} setDotColor={setDotColor}
            commaSeparatedTexts={commaSeparatedTexts} setCommaSeparatedTexts={setCommaSeparatedTexts}
            staticDuration={staticDuration} setStaticDuration={setStaticDuration}
            showIndicatorOnlyAtEnd={showIndicatorOnlyAtEnd} setShowIndicatorOnlyAtEnd={setShowIndicatorOnlyAtEnd}
            transitionDuration={transitionDuration} setTransitionDuration={setTransitionDuration}
            appearDuration={appearDuration} setAppearDuration={setAppearDuration}
            disappearDuration={disappearDuration} setDisappearDuration={setDisappearDuration}
            copyStateSettings={copyStateSettings} pasteStateSettings={pasteStateSettings}
            hasCopiedSettings={!!copiedStateSettings}
            exportConfiguration={exportConfiguration}
            showWithoutText={showWithoutText} setShowWithoutText={setShowWithoutText}
          />
          {showDetailedControls && (
            <div className="p-6 border-t border-gray-200">
              <EaseGraph value={easing} onChange={setEasing} />
            </div>
          )}
        </div>
        <div className="p-4 border-t border-gray-200 bg-gray-50">
          <button 
            onClick={() => setIsPaused(!isPaused)}
            className={`w-full py-3 rounded-lg font-medium transition-colors shadow-sm ${isPaused ? 'bg-green-600 hover:bg-green-700 text-white' : 'bg-yellow-600 hover:bg-yellow-700 text-white'}`}
          >
            {isPaused ? 'Play' : 'Pause'}
          </button>
        </div>
      </div>

      {/* Drag Handle */}
      <div 
        className="w-1 cursor-col-resize bg-gray-200 hover:bg-blue-500 transition-colors"
        onMouseDown={startResizing}
      />

      {/* Main Content: Mobile Frame */}
      <div className="flex-1 flex justify-center items-center p-4">
        <MobileFrame>
          <div className="mt-8">
            <div className="relative">
              {showWithoutText ? (
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: textAlignment === 'center' ? 'center' : textAlignment === 'right' ? 'flex-end' : 'flex-start',
                  width: '100%',
                }}>
                  <div className="flex items-center h-6">
                    <ThinkingIndicator 
                      state={state} 
                      speed={baseSpeed} 
                      speedMultiplier={currentStateSettings.speedMultiplier || 1}                      easing={easing} 
                      dotCount={currentStateSettings.dotCount}
                      spacing={currentStateSettings.spacing}
                      minWidth={state2Width}
                      color={dotColor}
                      size={currentStateSettings.size}
                      transitionDuration={transitionDuration}
                      waveHeight={currentStateSettings.waveHeight || 4}
                      dotDelay={currentStateSettings.dotDelay || 0.5}
                      opacity={currentStateSettings.opacity !== undefined ? currentStateSettings.opacity : 1}
                      dotFadeDelay={currentStateSettings.dotFadeDelay !== undefined ? currentStateSettings.dotFadeDelay : 0.05}
                      isDynamicDelay={currentStateSettings.isDynamicDelay}
                      dotDelayMin={currentStateSettings.dotDelayMin}
                      dotDelayMax={currentStateSettings.dotDelayMax}
                      delayCycleDuration={currentStateSettings.delayCycleDuration}
                      radius={currentStateSettings.radius}
                      spinSpeed={currentStateSettings.spinSpeed}
                      minRadius={currentStateSettings.minRadius}
                      maxRadius={currentStateSettings.maxRadius}
                      yOffset={currentStateSettings.yOffset}
                      appearDuration={appearDuration}
                      disappearDuration={disappearDuration}
                      isPaused={isPaused}
                      isFadingOut={fadeIndicatorWithText ? isTextFadingOut : false}
                      fadeIndicatorWithText={fadeIndicatorWithText}
                      alternateRotation={currentStateSettings.alternateRotation}
                    />
                  </div>
                </div>
              ) : (
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: textAlignment === 'center' ? 'center' : textAlignment === 'right' ? 'flex-end' : 'flex-start',
                  width: '100%',
                }}>
                  {indicatorPosition === 'above' && (
                    <div style={{ marginBottom: '8px' }}>
                      <ThinkingIndicator 
                        state={state} 
                        speed={baseSpeed} 
                        speedMultiplier={currentStateSettings.speedMultiplier || 1}
                        easing={easing} 
                        dotCount={currentStateSettings.dotCount}
                        spacing={currentStateSettings.spacing}
                        minWidth={state2Width}
                        color={dotColor}
                        size={currentStateSettings.size}
                        transitionDuration={transitionDuration}
                        waveHeight={currentStateSettings.waveHeight || 4}
                        dotDelay={currentStateSettings.dotDelay || 0.5}
                        opacity={currentStateSettings.opacity !== undefined ? currentStateSettings.opacity : 1}
                        dotFadeDelay={currentStateSettings.dotFadeDelay !== undefined ? currentStateSettings.dotFadeDelay : 0.05}
                        isDynamicDelay={currentStateSettings.isDynamicDelay}
                        dotDelayMin={currentStateSettings.dotDelayMin}
                        dotDelayMax={currentStateSettings.dotDelayMax}
                        delayCycleDuration={currentStateSettings.delayCycleDuration}
                        radius={currentStateSettings.radius}
                        spinSpeed={currentStateSettings.spinSpeed}
                        minRadius={currentStateSettings.minRadius}
                        maxRadius={currentStateSettings.maxRadius}
                        yOffset={currentStateSettings.yOffset}
                        appearDuration={appearDuration}
                        disappearDuration={disappearDuration}
                        isPaused={isPaused}
                        isFadingOut={fadeIndicatorWithText ? isTextFadingOut : false}
                        fadeIndicatorWithText={fadeIndicatorWithText}
                        alternateRotation={currentStateSettings.alternateRotation}
                      />
                    </div>
                  )}
                  <TextRenderer 
                    key={triggerKey}
                    text={currentText} 
                    duration={duration} 
                    overlap={overlap} 
                    easing={easing}
                    renderMode={renderMode}
                    showIndicatorOnlyAtEnd={showIndicatorOnlyAtEnd}
                    isPaused={isPaused}
                    isFadingOut={isTextFadingOut}
                    indicatorPosition={indicatorPosition}
                    textAlignment={textAlignment}
                    fadeIndicatorWithText={fadeIndicatorWithText}
                    textStyleOption={textStyleOption}
                    onComplete={handleTextComplete}
                    trailingComponent={indicatorPosition === 'end' ? (
                      <ThinkingIndicator 
                        state={state} 
                        speed={baseSpeed} 
                        speedMultiplier={currentStateSettings.speedMultiplier || 1}
                        easing={easing} 
                        dotCount={currentStateSettings.dotCount}
                        spacing={currentStateSettings.spacing}
                        minWidth={state2Width}
                        color={dotColor}
                        size={currentStateSettings.size}
                        transitionDuration={transitionDuration}
                        waveHeight={currentStateSettings.waveHeight || 4}
                        dotDelay={currentStateSettings.dotDelay || 0.5}
                        opacity={currentStateSettings.opacity !== undefined ? currentStateSettings.opacity : 1}
                        dotFadeDelay={currentStateSettings.dotFadeDelay !== undefined ? currentStateSettings.dotFadeDelay : 0.05}
                        isDynamicDelay={currentStateSettings.isDynamicDelay}
                        dotDelayMin={currentStateSettings.dotDelayMin}
                        dotDelayMax={currentStateSettings.dotDelayMax}
                        delayCycleDuration={currentStateSettings.delayCycleDuration}
                        radius={currentStateSettings.radius}
                        spinSpeed={currentStateSettings.spinSpeed}
                        minRadius={currentStateSettings.minRadius}
                        maxRadius={currentStateSettings.maxRadius}
                        yOffset={currentStateSettings.yOffset}
                        appearDuration={appearDuration}
                        disappearDuration={disappearDuration}
                        isPaused={isPaused}
                        isFadingOut={fadeIndicatorWithText ? isTextFadingOut : false}
                        fadeIndicatorWithText={fadeIndicatorWithText}
                        alternateRotation={currentStateSettings.alternateRotation}
                      />
                    ) : null}
                  />
                  {indicatorPosition === 'below' && (
                    <div style={{ marginTop: '8px' }}>
                      <ThinkingIndicator 
                        state={state} 
                        speed={baseSpeed} 
                        speedMultiplier={currentStateSettings.speedMultiplier || 1}
                        easing={easing} 
                        dotCount={currentStateSettings.dotCount}
                        spacing={currentStateSettings.spacing}
                        minWidth={state2Width}
                        color={dotColor}
                        size={currentStateSettings.size}
                        transitionDuration={transitionDuration}
                        waveHeight={currentStateSettings.waveHeight || 4}
                        dotDelay={currentStateSettings.dotDelay || 0.5}
                        opacity={currentStateSettings.opacity !== undefined ? currentStateSettings.opacity : 1}
                        dotFadeDelay={currentStateSettings.dotFadeDelay !== undefined ? currentStateSettings.dotFadeDelay : 0.05}
                        isDynamicDelay={currentStateSettings.isDynamicDelay}
                        dotDelayMin={currentStateSettings.dotDelayMin}
                        dotDelayMax={currentStateSettings.dotDelayMax}
                        delayCycleDuration={currentStateSettings.delayCycleDuration}
                        radius={currentStateSettings.radius}
                        spinSpeed={currentStateSettings.spinSpeed}
                        minRadius={currentStateSettings.minRadius}
                        maxRadius={currentStateSettings.maxRadius}
                        yOffset={currentStateSettings.yOffset}
                        appearDuration={appearDuration}
                        disappearDuration={disappearDuration}
                        isPaused={isPaused}
                        isFadingOut={fadeIndicatorWithText ? isTextFadingOut : false}
                        fadeIndicatorWithText={fadeIndicatorWithText}
                        alternateRotation={currentStateSettings.alternateRotation}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </MobileFrame>
      </div>
    </div>
  );
}
