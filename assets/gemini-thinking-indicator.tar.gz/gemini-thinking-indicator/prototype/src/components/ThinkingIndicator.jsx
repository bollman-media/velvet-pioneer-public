import React, { useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, useAnimationFrame, usePresence } from 'framer-motion';

const getEasingFunc = (easing) => {
  if (Array.isArray(easing) && easing.length === 4) {
    const [x1, y1, x2, y2] = easing;
    return (x) => {
      let t = x;
      for (let i = 0; i < 5; i++) {
        const currentX = 3 * (1 - t) * (1 - t) * t * x1 + 3 * (1 - t) * t * t * x2 + t * t * t;
        const derivative = 3 * (1 - t) * (1 - t) * x1 + 6 * (1 - t) * t * (x2 - x1) + 3 * t * t * (1 - x2);
        if (Math.abs(derivative) < 1e-6) break;
        t -= (currentX - x) / derivative;
        t = Math.max(0, Math.min(1, t)); // Clamp
      }
      return 3 * (1 - t) * (1 - t) * t * y1 + 3 * (1 - t) * t * t * y2 + t * t * t;
    };
  }
  if (easing === 'easeInOut') {
    return (t) => 0.5 * (1 - Math.cos(Math.PI * t));
  }
  if (easing === 'easeIn') {
    return (t) => t * t;
  }
  if (easing === 'easeOut') {
    return (t) => t * (2 - t);
  }
  return (t) => t; // linear fallback
};

function getPointForState(state, t, i, dotCount, size, spacing, radius, spinSpeed, minRadius, maxRadius, yOffset, speed, dotDelay, isDynamicDelay, dotDelayMin, dotDelayMax, delayCycleDuration, waveHeight, easingFunc, alternateRotation, pathWidth, pathHeight, speedMultiplier) {
  let targetX = 0;
  let targetY = 0;

  const totalWidth = dotCount * size + (dotCount - 1) * spacing;
  const initialX = i * (size + spacing) + size / 2;
  const centerOffsetX = totalWidth / 2 - initialX;

  const effectiveSpeed = speed * (speedMultiplier !== undefined ? speedMultiplier : 1);

  if (state === 5) {
    // Spinner
    const frequency = 0.003 * effectiveSpeed * (spinSpeed !== undefined ? spinSpeed : 1);
    const theta = t * frequency + i * (2 * Math.PI / dotCount);
    
    const minR = minRadius !== undefined ? minRadius : 8;
    const maxR = maxRadius !== undefined ? maxRadius : 16;
    const baseRadius = (minR + maxR) / 2;
    const amplitude = (maxR - minR) / 2;
    
    const r = baseRadius + amplitude * Math.cos(dotCount * theta);
    const scaleFactor = 1 + 0.2 * Math.sin(t * 0.002);
    const finalR = r * scaleFactor;
    
    targetX = centerOffsetX + finalR * Math.cos(theta);
    targetY = (yOffset !== undefined ? yOffset : -5) + finalR * Math.sin(theta);
  } else if (state === 6) {
    // Juggle
    const frequency = 0.003 * effectiveSpeed;
    const theta = t * frequency + i * (2 * Math.PI / dotCount);
    
    const r = radius !== undefined ? radius : 15;
    // Figure-8 path
    targetX = centerOffsetX + r * Math.cos(theta);
    targetY = (yOffset !== undefined ? yOffset : -5) + (r * 2 / 3) * Math.sin(2 * theta);
  } else if (state === 7) {
    // Processing (Aggressive Wave)
    const frequency = 0.007 * effectiveSpeed;
    const phase = t * frequency - i * dotDelay;
    targetY = (Math.sin(phase) - 1) * waveHeight;
    targetX = 0;

    
  } else if (state === 10) {
    // Technical (Pairwise Swapping)
    // Dots in a row. Pair(0,1) swap via 180° arc, then pair(1,2) swap, alternating.
    const yOff = yOffset !== undefined ? yOffset : 0;
    const frequency = 0.003 * effectiveSpeed;
    const slotWidth = size + spacing;
    const fullCycle = 6; // 6 phases returns 3 dots to start
    const phaseDuration = Math.PI;

    const globalAngle = t * frequency;
    const currentPhase = Math.floor(globalAngle / phaseDuration) % fullCycle;
    const rawProgress = (globalAngle / phaseDuration) - Math.floor(globalAngle / phaseDuration);
    // Apply easing curve to the swap progress
    const phaseProgress = easingFunc ? easingFunc(rawProgress) : rawProgress;

    // Simulate permutation: dotSlots[d] = which slot dot d occupies
    const dotSlots = Array.from({length: dotCount}, (_, d) => d);
    for (let p = 0; p < currentPhase; p++) {
      const sA = p % 2;
      const sB = sA + 1;
      if (sB >= dotCount) continue;
      let dA = -1, dB = -1;
      for (let d = 0; d < dotCount; d++) {
        if (dotSlots[d] === sA) dA = d;
        if (dotSlots[d] === sB) dB = d;
      }
      if (dA >= 0 && dB >= 0) { dotSlots[dA] = sB; dotSlots[dB] = sA; }
    }

    // Current active pair
    const activeSlotA = currentPhase % 2;
    const activeSlotB = activeSlotA + 1;
    const mySlot = dotSlots[i];
    const isSwapping = activeSlotB < dotCount && (mySlot === activeSlotA || mySlot === activeSlotB);

    if (isSwapping) {
      const midSlot = (activeSlotA + activeSlotB) / 2 - (dotCount - 1) / 2;
      const midX = midSlot * slotWidth;
      const halfDist = slotWidth / 2;
      // Alternate rotation direction: pair 0 goes one way, pair 1 goes the other
      const dir = (alternateRotation && activeSlotA === 1) ? -1 : 1;
      const startAngle = (mySlot === activeSlotA) ? Math.PI : 0;
      const angle = startAngle + dir * phaseProgress * Math.PI;

      const arcX = midX + halfDist * Math.cos(angle);
      const arcY = yOff + halfDist * Math.sin(angle);
      targetX = arcX + centerOffsetX;
      targetY = arcY;
    } else {
      const slotPos = (mySlot - (dotCount - 1) / 2) * slotWidth;
      targetX = slotPos + centerOffsetX;
      targetY = yOff;
    }
  } else if (state === 11) {
    // Advanced (Snake Juggle)
    const frequency = 0.003 * effectiveSpeed;
    const theta = t * frequency - i * (dotDelay !== undefined ? dotDelay : 0.2);
    
    const w = pathWidth !== undefined ? pathWidth : 15;
    const h = pathHeight !== undefined ? pathHeight : 10;
    targetX = centerOffsetX + w * Math.cos(theta);
    targetY = (yOffset !== undefined ? yOffset : -5) + h * Math.sin(2 * theta);
  } else {
    // Default wave
    const frequency = 0.005 * effectiveSpeed;
    
    let currentDotDelay = dotDelay;
    if (isDynamicDelay) {
      const cycleProgress = (t % delayCycleDuration) / delayCycleDuration;
      const factor = 0.5 + 0.5 * Math.sin(cycleProgress * 2 * Math.PI);
      currentDotDelay = dotDelayMin + (dotDelayMax - dotDelayMin) * factor;
    }

    const phase = t * frequency - i * currentDotDelay;
    targetY = (Math.sin(phase) - 1) * waveHeight;
    targetX = 0;
  }
  return { x: targetX, y: targetY };
}

function Dot({ i, speed, state, color, transitionDuration, easing, disappearDuration, waveHeight, dotDelay, opacity = 1, isDynamicDelay, dotDelayMin = 0.1, dotDelayMax = 1.0, delayCycleDuration = 3000, isFadingOut = false, size, spacing, dotCount, radius, spinSpeed, minRadius, maxRadius, yOffset, alternateRotation, pathWidth, pathHeight, speedMultiplier }) {
  const [isPresent, safeToRemove] = usePresence();
  const y = useMotionValue(0);
  const x = useMotionValue(0);
  const currentWaveHeightRef = useRef(0);
  const startHeightRef = useRef(0);
  const transitionStartTimeRef = useRef(null);
  const prevTargetHeightRef = useRef(0);
  
  const currentXRef = useRef(0);
  const currentYRef = useRef(0);
  const lastStateRef = useRef(state);
  const posTransitionStartTimeRef = useRef(null);
  const lastTRef = useRef(performance.now());
  
  const lastDxRef = useRef(0);
  const lastDyRef = useRef(0);
  const startXRef = useRef(0);
  const startYRef = useRef(0);
  const startDxRef = useRef(0);
  const startDyRef = useRef(0);

  const easingFunc = getEasingFunc(easing);

  useAnimationFrame(() => {
    const t = performance.now();
    const dt = t - lastTRef.current;
    lastTRef.current = t;
    
    if (state !== lastStateRef.current) {
      posTransitionStartTimeRef.current = t;
      startXRef.current = currentXRef.current;
      startYRef.current = currentYRef.current;
      startDxRef.current = lastDxRef.current;
      startDyRef.current = lastDyRef.current;
      lastStateRef.current = state;
    }
    
    // Calculate wave target height
    const targetHeight = (state === 1 || !isPresent) ? 0 : waveHeight;
    
    // Detect target height change
    if (targetHeight !== prevTargetHeightRef.current) {
      startHeightRef.current = currentWaveHeightRef.current;
      transitionStartTimeRef.current = t;
      prevTargetHeightRef.current = targetHeight;
    }

    // Animate wave height with easing
    if (transitionStartTimeRef.current !== null) {
      const progress = (t - transitionStartTimeRef.current) / transitionDuration;
      if (progress >= 1) {
        currentWaveHeightRef.current = targetHeight;
        transitionStartTimeRef.current = null;
      } else {
        const easedProgress = easingFunc(progress);
        currentWaveHeightRef.current = startHeightRef.current + (targetHeight - startHeightRef.current) * easedProgress;
      }
    }

    // Get point for new state
    const p_new = getPointForState(state, t, i, dotCount, size, spacing, radius, spinSpeed, minRadius, maxRadius, yOffset, speed, dotDelay, isDynamicDelay, dotDelayMin, dotDelayMax, delayCycleDuration, currentWaveHeightRef.current, easingFunc, alternateRotation, pathWidth, pathHeight, speedMultiplier);
    
    let finalX, finalY;
    
    if (posTransitionStartTimeRef.current !== null) {
      const progress = (t - posTransitionStartTimeRef.current) / transitionDuration;
      if (progress >= 1) {
        finalX = p_new.x;
        finalY = p_new.y;
        posTransitionStartTimeRef.current = null;
      } else {
        const easedProgress = easingFunc(progress);
        
        // Linear extrapolation of old state path to preserve momentum
        const framesElapsed = (t - posTransitionStartTimeRef.current) / 16.6;
        const oldX = startXRef.current + startDxRef.current * framesElapsed;
        const oldY = startYRef.current + startDyRef.current * framesElapsed;
        
        finalX = oldX + (p_new.x - oldX) * easedProgress;
        finalY = oldY + (p_new.y - oldY) * easedProgress;
      }
    } else {
      finalX = p_new.x;
      finalY = p_new.y;
    }
    
    const dx = finalX - currentXRef.current;
    const dy = finalY - currentYRef.current;
    lastDxRef.current = dx;
    lastDyRef.current = dy;
    
    currentXRef.current = finalX;
    currentYRef.current = finalY;
    
    x.set(finalX);
    y.set(finalY);

    // Call safeToRemove when exiting and wave has died down
    if (!isPresent && Math.abs(currentWaveHeightRef.current) < 0.1) {
      safeToRemove();
    }
  });

  return (
    <motion.div
      className="w-full h-full rounded-full"
      animate={{ opacity: isFadingOut ? 0 : opacity }}
      transition={{ duration: isFadingOut ? 0.5 : transitionDuration / 1000, ease: easing }}
      style={{ backgroundColor: color, x, y }}
    />
  );
}

export default function ThinkingIndicator({ dotCount = 3, spacing = 4, speed = 1, easing = "easeInOut", state, color = '#000000', size = 8, transitionDuration = 300, minWidth = 0, appearDuration = 300, disappearDuration = 300, waveHeight = 4, dotDelay = 0.5, opacity = 1, isDynamicDelay, dotDelayMin = 0.1, dotDelayMax = 1.0, delayCycleDuration = 3000, dotFadeDelay = 0.05, isFadingOut = false, radius, spinSpeed, minRadius, maxRadius, yOffset, fadeIndicatorWithText = true, alternateRotation = false, pathWidth, pathHeight, speedMultiplier }) {
  const dots = Array.from({ length: dotCount });

  const dotVariants = {
    initial: { 
      scale: 1, 
      opacity: fadeIndicatorWithText ? 0 : 1 
    },
    animate: (i) => ({
      scale: 1,
      opacity: 1,
      transition: {
        opacity: { 
          duration: fadeIndicatorWithText ? appearDuration / 1000 : 0, 
          ease: easing, 
          delay: i * dotFadeDelay 
        }
      }
    }),
    exit: (i) => ({
      scale: fadeIndicatorWithText ? 1 : 0,
      opacity: 0,
      transition: {
        opacity: { 
          duration: fadeIndicatorWithText ? disappearDuration / 1000 : 0, 
          ease: easing, 
          delay: (dotCount - 1 - i) * dotFadeDelay 
        },
        scale: { 
          duration: fadeIndicatorWithText ? 0 : disappearDuration / 1000, 
          ease: easing, 
          delay: (dotCount - 1 - i) * dotFadeDelay 
        }
      }
    }),
  };

  return (
    <motion.div 
      layout="position"
      className="inline-flex items-center h-6 ml-1" 
      style={{ gap: `${spacing}px`, minWidth: `${minWidth}px` }}
    >
      <AnimatePresence>
        {dots.map((_, i) => (
          <motion.div
            key={i}
            className="rounded-full"
            custom={i}
            variants={dotVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            style={{ width: `${size}px`, height: `${size}px`, display: 'inline-block', position: 'relative' }}
          >
            <Dot i={i} speed={speed} state={state} color={color} transitionDuration={transitionDuration} easing={easing} disappearDuration={disappearDuration} waveHeight={waveHeight} dotDelay={dotDelay} opacity={opacity} isDynamicDelay={isDynamicDelay} dotDelayMin={dotDelayMin} dotDelayMax={dotDelayMax} delayCycleDuration={delayCycleDuration} isFadingOut={isFadingOut} size={size} spacing={spacing} dotCount={dotCount} radius={radius} spinSpeed={spinSpeed} minRadius={minRadius} maxRadius={maxRadius} yOffset={yOffset} alternateRotation={alternateRotation} pathWidth={pathWidth} pathHeight={pathHeight} speedMultiplier={speedMultiplier} />
          </motion.div>
        ))}
      </AnimatePresence>
    </motion.div>
  );
}
