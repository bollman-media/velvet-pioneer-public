import React from 'react';

const stateNames = {
  1: "Idle",
  2: "Wave",
  4: "Dynamic Wave",
  5: "Spinner",
  6: "Juggle",
  7: "Processing",
  10: "Technical",
  11: "Advanced"
};

export default function ControlsPanel({ 
  showDetailedControls,
  indicatorPosition, setIndicatorPosition,
  textAlignment, setTextAlignment,
  fadeIndicatorWithText, setFadeIndicatorWithText,
  textStyleOption, setTextStyleOption,
  duration, setDuration, 
  overlap, setOverlap, 
  state, setState, 
  baseSpeed, setBaseSpeed,
  renderMode, setRenderMode,
  triggerAnimation,
  presets = [], loadPreset, savePreset, deletePreset,
  stateSettings, setStateSettings,
  nextTargetIndices,
  dotColor, setDotColor,
  commaSeparatedTexts, setCommaSeparatedTexts,
  staticDuration, setStaticDuration,
  showIndicatorOnlyAtEnd, setShowIndicatorOnlyAtEnd,
  transitionDuration, setTransitionDuration,
  appearDuration, setAppearDuration,
  disappearDuration, setDisappearDuration,
  state2Delay, setState2Delay,
  copyStateSettings, pasteStateSettings, hasCopiedSettings,
  exportConfiguration,
  showWithoutText, setShowWithoutText
}) {
  return (
    <div className="p-6 flex flex-col space-y-6 font-sans">
      
      {/* SIMPLE CONTROLS (Always visible) */}
      
      {/* Presets */}
      <div className="space-y-3">
        <h3 className="text-sm font-medium text-gray-700">Presets</h3>
        {presets.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {presets.map((preset, index) => (
              <div key={index} className="flex items-center space-x-1 bg-gray-100 px-3 py-1 rounded-full text-xs font-medium">
                <button onClick={() => loadPreset(preset)} className="text-gray-700 hover:text-blue-600">{preset.name}</button>
                <button onClick={() => deletePreset(preset.name)} className="text-gray-400 hover:text-red-500 text-sm ml-1">×</button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-gray-400">No presets saved yet.</p>
        )}
        <div className="flex space-x-2">
          <input 
            type="text" 
            id="preset-name" 
            placeholder="New Preset" 
            className="flex-1 text-xs border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-500" 
          />
          <button 
            onClick={() => {
              const input = document.getElementById('preset-name');
              const name = input.value;
              if (name) {
                savePreset(name);
                input.value = '';
              }
            }}
            className="text-xs bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
          >
            Save
          </button>
        </div>
      </div>

      {/* Text List */}
      <div className="space-y-3">
        <label className="text-xs text-gray-500 flex justify-between">
          <span>Text List (comma separated)</span>
        </label>
        <textarea 
          value={commaSeparatedTexts} 
          onChange={(e) => setCommaSeparatedTexts(e.target.value)}
          className="w-full mt-1 text-xs border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-500"
          rows="3"
        />
      </div>

      {/* State Selector */}
      <div className="space-y-3">
        <label className="text-xs text-gray-500">State</label>
        <div className="space-y-2 mt-1">
          <div className="flex gap-2">
            {[1, 2, 4, 5].map((s) => (
              <button
                key={s}
                onClick={() => setState(s)}
                className={`flex-1 py-2 rounded-lg text-xs font-medium transition-colors ${state === s ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
              >
                {stateNames[s]}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            {[6, 7, 10, 11].map((s) => (
              <button
                key={s}
                onClick={() => setState(s)}
                className={`flex-1 py-2 rounded-lg text-xs font-medium transition-colors ${state === s ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
              >
                {stateNames[s]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Position */}
      <div className="space-y-3">
        <label className="text-xs text-gray-500">Position</label>
        <div className="flex flex-wrap gap-2 mt-1">
          {['end', 'above', 'below'].map((pos) => (
            <button
              key={pos}
              onClick={() => setIndicatorPosition(pos)}
              className={`flex-1 py-2 rounded-lg text-xs font-medium transition-colors ${indicatorPosition === pos ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
            >
              {pos === 'end' ? 'Inline' : pos.charAt(0).toUpperCase() + pos.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Text Alignment */}
      <div className="space-y-3">
        <label className="text-xs text-gray-500">Text Alignment</label>
        <div className="flex flex-wrap gap-2 mt-1">
          {['left', 'center', 'right'].map((align) => (
            <button
              key={align}
              onClick={() => setTextAlignment(align)}
              className={`flex-1 py-2 rounded-lg text-xs font-medium transition-colors ${textAlignment === align ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
            >
              {align.charAt(0).toUpperCase() + align.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Fade Indicator With Text */}
      <div className="flex items-center space-x-2 mt-2">
        <input
          type="checkbox"
          id="fadeIndicatorWithText"
          checked={fadeIndicatorWithText}
          onChange={(e) => setFadeIndicatorWithText(e.target.checked)}
          className="rounded text-blue-600 focus:ring-blue-500"
        />
        <label htmlFor="fadeIndicatorWithText" className="text-xs text-gray-700 font-medium">
          Fade with text
        </label>
      </div>

      {/* Show Without Text */}
      <div className="flex items-center justify-between mt-2">
        <label className="text-xs text-gray-700 font-medium">Show Without Text</label>
        <input
          type="checkbox"
          checked={showWithoutText}
          onChange={(e) => setShowWithoutText(e.target.checked)}
          className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
        />
      </div>

      {/* Static Duration */}
      <div className="mt-2">
        <label className="text-xs text-gray-700 flex justify-between">
          <span className="font-medium">Static Duration ({staticDuration}ms)</span>
        </label>
        <input 
          type="range" min="0" max="5000" step="100" 
          value={staticDuration} onChange={(e) => setStaticDuration(Number(e.target.value))}
          className="w-full mt-1"
        />
      </div>

      {/* DETAILED CONTROLS */}
      {showDetailedControls && (
        <>
          <hr className="border-gray-200" />
          
          {/* Text Animation Details */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-700">Text Animation Details</h3>
            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Char Duration ({duration}ms)</span>
              </label>
              <input 
                type="range" min="50" max="1000" step="10" 
                value={duration} onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full mt-1"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Overlap ({overlap}ms)</span>
              </label>
              <input 
                type="range" min="0" max="500" step="10" 
                value={overlap} onChange={(e) => setOverlap(Number(e.target.value))}
                className="w-full mt-1"
              />
            </div>
            <div className="flex space-x-2">
              <button 
                onClick={() => { setRenderMode('char'); triggerAnimation(); }}
                className={`flex-1 text-xs py-2 rounded-lg font-medium transition-colors ${renderMode === 'char' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
              >
                Char by Char
              </button>
              <button 
                onClick={() => { setRenderMode('word'); triggerAnimation(); }}
                className={`flex-1 text-xs py-2 rounded-lg font-medium transition-colors ${renderMode === 'word' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
              >
                Word by Word
              </button>
            </div>
            <div>
              <label className="text-xs text-gray-500 block mb-1">Text Style</label>
              <select 
                value={textStyleOption} 
                onChange={(e) => setTextStyleOption(e.target.value)}
                className="w-full text-sm border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              >
                <option value="TLDR">LR26/TLDR</option>
                <option value="DisplayS">LR26/Display S</option>
              </select>
            </div>

          </div>

          <hr className="border-gray-200" />

          {/* Thinking Indicator Details */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-700">Indicator Details (State {state})</h3>
            
            <div className="flex space-x-2">
              <button
                onClick={copyStateSettings}
                className="flex-1 py-1 rounded-lg text-xs font-medium bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
              >
                Copy State
              </button>
              <button
                onClick={pasteStateSettings}
                disabled={!hasCopiedSettings}
                className={`flex-1 py-1 rounded-lg text-xs font-medium transition-colors ${hasCopiedSettings ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' : 'bg-gray-50 text-gray-400 cursor-not-allowed'}`}
              >
                Paste State
              </button>
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Base Wave Speed ({baseSpeed}x)</span>
              </label>
              <input 
                type="range" min="0.1" max="3" step="0.1" 
                value={baseSpeed} onChange={(e) => setBaseSpeed(Number(e.target.value))}
                className="w-full mt-1"
              />
            </div>
            
            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Transition Duration (ms)</span>
              </label>
              <input 
                type="number" 
                value={transitionDuration} 
                onChange={(e) => setTransitionDuration(Number(e.target.value))}
                className="w-full mt-1 text-xs border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Appear Duration (ms)</span>
              </label>
              <input 
                type="number" 
                value={appearDuration} 
                onChange={(e) => setAppearDuration(Number(e.target.value))}
                className="w-full mt-1 text-xs border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Disappear Duration (ms)</span>
              </label>
              <input 
                type="number" 
                value={disappearDuration} 
                onChange={(e) => setDisappearDuration(Number(e.target.value))}
                className="w-full mt-1 text-xs border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Dot Count ({stateSettings[state].dotCount})</span>
              </label>
              <input 
                type="range" min="1" max="20" step="1" 
                value={stateSettings[state].dotCount} 
                onChange={(e) => {
                  const newSettings = { ...stateSettings };
                  newSettings[state] = { ...newSettings[state], dotCount: Number(e.target.value) };
                  setStateSettings(newSettings);
                }}
                className="w-full mt-1"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Dot Spacing ({stateSettings[state].spacing}px)</span>
              </label>
              <input 
                type="range" min="0" max="20" step="1" 
                value={stateSettings[state].spacing} 
                onChange={(e) => {
                  const newSettings = { ...stateSettings };
                  newSettings[state] = { ...newSettings[state], spacing: Number(e.target.value) };
                  setStateSettings(newSettings);
                }}
                className="w-full mt-1"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Dot Size ({stateSettings[state].size}px)</span>
              </label>
              <input 
                type="range" min="2" max="20" step="1" 
                value={stateSettings[state].size} 
                onChange={(e) => {
                  const newSettings = { ...stateSettings };
                  newSettings[state] = { ...newSettings[state], size: Number(e.target.value) };
                  setStateSettings(newSettings);
                }}
                className="w-full mt-1"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Wave Height ({stateSettings[state].waveHeight !== undefined ? stateSettings[state].waveHeight : 4}px)</span>
              </label>
              <input 
                type="range" min="0" max="20" step="0.5" 
                value={stateSettings[state].waveHeight !== undefined ? stateSettings[state].waveHeight : 4} 
                onChange={(e) => {
                  const newSettings = { ...stateSettings };
                  newSettings[state] = { ...newSettings[state], waveHeight: Number(e.target.value) };
                  setStateSettings(newSettings);
                }}
                className="w-full mt-1"
              />
            </div>

            {state === 5 && (
              <>
                <div>
                  <label className="text-xs text-gray-500 flex justify-between">
                    <span>Min Radius ({stateSettings[state].minRadius !== undefined ? stateSettings[state].minRadius : 8}px)</span>
                  </label>
                  <input 
                    type="range" min="2" max="30" step="1" 
                    value={stateSettings[state].minRadius !== undefined ? stateSettings[state].minRadius : 8} 
                    onChange={(e) => {
                      const newSettings = { ...stateSettings };
                      newSettings[state] = { ...newSettings[state], minRadius: Number(e.target.value) };
                      setStateSettings(newSettings);
                    }}
                    className="w-full mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 flex justify-between">
                    <span>Max Radius ({stateSettings[state].maxRadius !== undefined ? stateSettings[state].maxRadius : 16}px)</span>
                  </label>
                  <input 
                    type="range" min="5" max="50" step="1" 
                    value={stateSettings[state].maxRadius !== undefined ? stateSettings[state].maxRadius : 16} 
                    onChange={(e) => {
                      const newSettings = { ...stateSettings };
                      newSettings[state] = { ...newSettings[state], maxRadius: Number(e.target.value) };
                      setStateSettings(newSettings);
                    }}
                    className="w-full mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 flex justify-between">
                    <span>Spin Speed ({stateSettings[state].spinSpeed !== undefined ? stateSettings[state].spinSpeed : 1}x)</span>
                  </label>
                  <input 
                    type="range" min="0.1" max="5" step="0.1" 
                    value={stateSettings[state].spinSpeed !== undefined ? stateSettings[state].spinSpeed : 1} 
                    onChange={(e) => {
                      const newSettings = { ...stateSettings };
                      newSettings[state] = { ...newSettings[state], spinSpeed: Number(e.target.value) };
                      setStateSettings(newSettings);
                    }}
                    className="w-full mt-1"
                  />
                </div>
              </>
            )}

            {state === 6 && (
              <div>
                <label className="text-xs text-gray-500 flex justify-between">
                  <span>Radius ({stateSettings[state].radius !== undefined ? stateSettings[state].radius : 15}px)</span>
                </label>
                <input 
                  type="range" min="5" max="50" step="1" 
                  value={stateSettings[state].radius !== undefined ? stateSettings[state].radius : 15} 
                  onChange={(e) => {
                    const newSettings = { ...stateSettings };
                    newSettings[state] = { ...newSettings[state], radius: Number(e.target.value) };
                    setStateSettings(newSettings);
                  }}
                  className="w-full mt-1"
                />
              </div>
            )}

            {(state === 5 || state === 6) && (
              <div>
                <label className="text-xs text-gray-500 flex justify-between">
                  <span>Vertical Offset ({stateSettings[state].yOffset !== undefined ? stateSettings[state].yOffset : -5}px)</span>
                </label>
                <input 
                  type="range" min="-20" max="20" step="1" 
                  value={stateSettings[state].yOffset !== undefined ? stateSettings[state].yOffset : -5} 
                  onChange={(e) => {
                    const newSettings = { ...stateSettings };
                    newSettings[state] = { ...newSettings[state], yOffset: Number(e.target.value) };
                    setStateSettings(newSettings);
                  }}
                  className="w-full mt-1"
                />
              </div>
            )}

            {state === 10 && (
              <div className="flex items-center justify-between">
                <label className="text-xs text-gray-500">Alternate Rotation Direction</label>
                <input 
                  type="checkbox" 
                  checked={stateSettings[state].alternateRotation || false} 
                  onChange={(e) => {
                    const newSettings = { ...stateSettings };
                    newSettings[state] = { ...newSettings[state], alternateRotation: e.target.checked };
                    setStateSettings(newSettings);
                  }}
                  className="form-checkbox h-4 w-4 text-blue-600"
                />
              </div>
            )}

            {state === 11 && (
              <>
                <div>
                  <label className="text-xs text-gray-500 flex justify-between">
                    <span>Path Width ({stateSettings[state].pathWidth !== undefined ? stateSettings[state].pathWidth : 15}px)</span>
                  </label>
                  <input 
                    type="range" min="5" max="50" step="1" 
                    value={stateSettings[state].pathWidth !== undefined ? stateSettings[state].pathWidth : 15} 
                    onChange={(e) => {
                      const newSettings = { ...stateSettings };
                      newSettings[state] = { ...newSettings[state], pathWidth: Number(e.target.value) };
                      setStateSettings(newSettings);
                    }}
                    className="w-full mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 flex justify-between">
                    <span>Path Height ({stateSettings[state].pathHeight !== undefined ? stateSettings[state].pathHeight : 10}px)</span>
                  </label>
                  <input 
                    type="range" min="5" max="50" step="1" 
                    value={stateSettings[state].pathHeight !== undefined ? stateSettings[state].pathHeight : 10} 
                    onChange={(e) => {
                      const newSettings = { ...stateSettings };
                      newSettings[state] = { ...newSettings[state], pathHeight: Number(e.target.value) };
                      setStateSettings(newSettings);
                    }}
                    className="w-full mt-1"
                  />
                </div>
              </>
            )}

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Dot Delay ({stateSettings[state].dotDelay !== undefined ? stateSettings[state].dotDelay : 0.5})</span>
              </label>
              <input 
                type="range" min="0" max="2" step="0.05" 
                value={stateSettings[state].dotDelay !== undefined ? stateSettings[state].dotDelay : 0.5} 
                onChange={(e) => {
                  const newSettings = { ...stateSettings };
                  newSettings[state] = { ...newSettings[state], dotDelay: Number(e.target.value) };
                  setStateSettings(newSettings);
                }}
                className="w-full mt-1"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Speed Multiplier ({stateSettings[state].speedMultiplier !== undefined ? stateSettings[state].speedMultiplier : 1}x)</span>
              </label>
              <input 
                type="range" min="0.1" max="5" step="0.1" 
                value={stateSettings[state].speedMultiplier !== undefined ? stateSettings[state].speedMultiplier : 1} 
                onChange={(e) => {
                  const newSettings = { ...stateSettings };
                  newSettings[state] = { ...newSettings[state], speedMultiplier: Number(e.target.value) };
                  setStateSettings(newSettings);
                }}
                className="w-full mt-1"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Dot Fade Delay ({stateSettings[state].dotFadeDelay !== undefined ? stateSettings[state].dotFadeDelay : 0.05}s)</span>
              </label>
              <input 
                type="range" min="0" max="0.5" step="0.01" 
                value={stateSettings[state].dotFadeDelay !== undefined ? stateSettings[state].dotFadeDelay : 0.05} 
                onChange={(e) => {
                  const newSettings = { ...stateSettings };
                  newSettings[state] = { ...newSettings[state], dotFadeDelay: Number(e.target.value) };
                  setStateSettings(newSettings);
                }}
                className="w-full mt-1"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Opacity ({stateSettings[state].opacity !== undefined ? stateSettings[state].opacity : 1})</span>
              </label>
              <input 
                type="range" min="0" max="1" step="0.05" 
                value={stateSettings[state].opacity !== undefined ? stateSettings[state].opacity : 1} 
                onChange={(e) => {
                  const newSettings = { ...stateSettings };
                  newSettings[state] = { ...newSettings[state], opacity: Number(e.target.value) };
                  setStateSettings(newSettings);
                }}
                className="w-full mt-1"
              />
            </div>

            {stateSettings[state].isDynamicDelay && (
              <>
                <div>
                  <label className="text-xs text-gray-500 flex justify-between">
                    <span>Min Dot Delay ({stateSettings[state].dotDelayMin !== undefined ? stateSettings[state].dotDelayMin : 0.1})</span>
                  </label>
                  <input 
                    type="range" min="0" max="2" step="0.05" 
                    value={stateSettings[state].dotDelayMin !== undefined ? stateSettings[state].dotDelayMin : 0.1} 
                    onChange={(e) => {
                      const newSettings = { ...stateSettings };
                      newSettings[state] = { ...newSettings[state], dotDelayMin: Number(e.target.value) };
                      setStateSettings(newSettings);
                    }}
                    className="w-full mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 flex justify-between">
                    <span>Max Dot Delay ({stateSettings[state].dotDelayMax !== undefined ? stateSettings[state].dotDelayMax : 1.0})</span>
                  </label>
                  <input 
                    type="range" min="0" max="2" step="0.05" 
                    value={stateSettings[state].dotDelayMax !== undefined ? stateSettings[state].dotDelayMax : 1.0} 
                    onChange={(e) => {
                      const newSettings = { ...stateSettings };
                      newSettings[state] = { ...newSettings[state], dotDelayMax: Number(e.target.value) };
                      setStateSettings(newSettings);
                    }}
                    className="w-full mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 flex justify-between">
                    <span>Delay Cycle Duration ({stateSettings[state].delayCycleDuration !== undefined ? stateSettings[state].delayCycleDuration : 3000}ms)</span>
                  </label>
                  <input 
                    type="range" min="500" max="10000" step="100" 
                    value={stateSettings[state].delayCycleDuration !== undefined ? stateSettings[state].delayCycleDuration : 3000} 
                    onChange={(e) => {
                      const newSettings = { ...stateSettings };
                      newSettings[state] = { ...newSettings[state], delayCycleDuration: Number(e.target.value) };
                      setStateSettings(newSettings);
                    }}
                    className="w-full mt-1"
                  />
                </div>
              </>
            )}

            <div>
              <div className="flex items-center justify-between">
                <label className="text-xs text-gray-500">No Timeout</label>
                <input 
                  type="checkbox" 
                  checked={stateSettings[state].noTimeout} 
                  onChange={(e) => {
                    const newSettings = { ...stateSettings };
                    newSettings[state] = { ...newSettings[state], noTimeout: e.target.checked };
                    setStateSettings(newSettings);
                  }}
                  className="form-checkbox h-4 w-4 text-blue-600"
                />
              </div>
            </div>

            {!stateSettings[state].noTimeout && (
              <div>
                <label className="text-xs text-gray-500 flex justify-between">
                  <span>Timeout (ms)</span>
                </label>
                <input 
                  type="number" 
                  value={stateSettings[state].timeout} 
                  onChange={(e) => {
                    const newSettings = { ...stateSettings };
                    newSettings[state] = { ...newSettings[state], timeout: Number(e.target.value) };
                    setStateSettings(newSettings);
                  }}
                  className="w-full mt-1 text-xs border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-500"
                />
              </div>
            )}

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Target States (Alternating)</span>
              </label>
              <div className="space-y-2 mt-1">
                <div className="flex gap-2">
                  {[1, 2, 4, 5].map((s) => {
                    const isTarget = stateSettings[state].targetStates?.includes(s);
                    const currentIndex = nextTargetIndices[state] || 0;
                    const nextTargetState = stateSettings[state].targetStates?.[currentIndex];
                    const isNext = s === nextTargetState;
                    
                    return (
                      <button
                        key={s}
                        onClick={() => {
                          const newSettings = { ...stateSettings };
                          const currentTargets = newSettings[state].targetStates || [];
                          let newTargets;
                          if (currentTargets.includes(s)) {
                            newTargets = currentTargets.filter(t => t !== s);
                          } else {
                            newTargets = [...currentTargets, s];
                          }
                          newSettings[state] = { ...newSettings[state], targetStates: newTargets };
                          setStateSettings(newSettings);
                        }}
                        className={`flex-1 py-1 rounded-lg text-xs font-medium transition-colors ${
                          isTarget 
                            ? isNext 
                              ? 'bg-green-600 text-white ring-2 ring-yellow-400' 
                              : 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                        title={isNext ? "Next Target State" : ""}
                      >
                        {stateNames[s]}
                      </button>
                    );
                  })}
                </div>
                <div className="flex gap-2">
                  {[6, 7, 10, 11].map((s) => {
                    const isTarget = stateSettings[state].targetStates?.includes(s);
                    const currentIndex = nextTargetIndices[state] || 0;
                    const nextTargetState = stateSettings[state].targetStates?.[currentIndex];
                    const isNext = s === nextTargetState;
                    
                    return (
                      <button
                        key={s}
                        onClick={() => {
                          const newSettings = { ...stateSettings };
                          const currentTargets = newSettings[state].targetStates || [];
                          let newTargets;
                          if (currentTargets.includes(s)) {
                            newTargets = currentTargets.filter(t => t !== s);
                          } else {
                            newTargets = [...currentTargets, s];
                          }
                          newSettings[state] = { ...newSettings[state], targetStates: newTargets };
                          setStateSettings(newSettings);
                        }}
                        className={`flex-1 py-1 rounded-lg text-xs font-medium transition-colors ${
                          isTarget 
                            ? isNext 
                              ? 'bg-green-600 text-white ring-2 ring-yellow-400' 
                              : 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                        title={isNext ? "Next Target State" : ""}
                      >
                        {stateNames[s]}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs text-gray-500 flex justify-between">
                <span>Dot Color</span>
              </label>
              <div className="flex items-center space-x-2 mt-1">
                <input 
                  type="color" 
                  value={dotColor} 
                  onChange={(e) => setDotColor(e.target.value)}
                  className="h-8 w-8 cursor-pointer rounded"
                />
                <span className="text-xs text-gray-700">{dotColor}</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="text-xs text-gray-500">Show Only At End</label>
              <input 
                type="checkbox" 
                checked={showIndicatorOnlyAtEnd} 
                onChange={(e) => setShowIndicatorOnlyAtEnd(e.target.checked)}
                className="form-checkbox h-4 w-4 text-blue-600"
              />
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Export */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-700">Export</h3>
            <button 
              onClick={exportConfiguration}
              className="w-full text-xs bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 transition-colors"
            >
              Export All Settings
            </button>
          </div>
        </>
      )}
    </div>
  );
}
