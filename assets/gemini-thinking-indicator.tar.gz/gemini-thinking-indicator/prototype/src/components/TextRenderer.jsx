import React from 'react';
import { motion } from 'framer-motion';

export default function TextRenderer({ 
  text, 
  duration, 
  overlap, 
  easing, 
  renderMode, 
  trailingComponent, 
  showIndicatorOnlyAtEnd = false, 
  onComplete, 
  isPaused, 
  isFadingOut,
  indicatorPosition = 'end',
  textAlignment = 'left',
  textStyleOption = 'TLDR',
  triggerKey,
  fadeIndicatorWithText = true
}) {
  const charDuration = duration / 1000;
  const items = renderMode === 'word' ? text.split(' ') : text.split('');
  
  const [visibleCount, setVisibleCount] = React.useState(0);
  const onCompleteCalledRef = React.useRef(false);
  const onCompleteRef = React.useRef(onComplete);
  React.useEffect(() => { onCompleteRef.current = onComplete; }, [onComplete]);
  
  // Reset visible count and completion flag when text or triggerKey changes
  React.useEffect(() => {
    setVisibleCount(0);
    onCompleteCalledRef.current = false;
  }, [text, renderMode, triggerKey]);

  // Progressively reveal items
  React.useEffect(() => {
    if (isPaused) return;
    
    const intervalTime = overlap;
    
    if (intervalTime === 0) {
      setVisibleCount(items.length);
      return;
    }

    const timer = setInterval(() => {
      setVisibleCount((prev) => {
        if (prev >= items.length) {
          clearInterval(timer);
          return prev;
        }
        return prev + 1;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [overlap, items.length, isPaused, triggerKey]);

  // Fire onComplete exactly once after the last item has faded in
  React.useEffect(() => {
    if (visibleCount >= items.length && visibleCount > 0 && onCompleteRef.current && !onCompleteCalledRef.current) {
      onCompleteCalledRef.current = true;
      // Wait for the last item's fade-in animation to finish
      const timer = setTimeout(() => {
        onCompleteRef.current?.();
      }, duration);
      return () => clearTimeout(timer);
    }
  }, [visibleCount, items.length, duration]);

  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: textAlignment === 'center' ? 'center' : textAlignment === 'right' ? 'flex-end' : 'flex-start',
    width: '100%',
  };

  const styles = {
    TLDR: {
      color: 'var(--On-Surfaces-On-Surface, #000)',
      fontFamily: 'var(--Font-family-TLDR, "Google Sans Flex")',
      fontSize: 'var(--Font-size-Headline-M, 24px)',
      fontStyle: 'normal',
      fontWeight: '380',
      lineHeight: 'var(--Line-height-TLDR, 28px)',
      letterSpacing: 'var(--Letter-spacing-TLDR, 0)',
      textAlign: textAlignment,
      width: '100%',
    },
    DisplayS: {
      color: 'var(--On-Surfaces-On-Surface, #000)',
      fontFamily: '"Google Sans Flex"',
      fontSize: '32px',
      fontStyle: 'normal',
      fontWeight: '360',
      lineHeight: '38px',
      letterSpacing: 'var(--Letter-spacing-Headline-L, 0)',
      textAlign: 'center',
      width: '100%',
    }
  };

  const textStyle = styles[textStyleOption] || styles.TLDR;

  const isComplete = visibleCount >= items.length;
  const shouldShowIndicator = !fadeIndicatorWithText || !showIndicatorOnlyAtEnd || isComplete || isPaused;

  const renderTextContent = () => {
    if (renderMode === 'word') {
      return (
        <div className="text-content" style={textStyle}>
          {items.slice(0, visibleCount).map((word, index) => (
            <motion.span
              key={index}
              initial={{ opacity: 0 }}
              animate={{ opacity: isFadingOut ? 0 : 1 }}
              transition={{
                duration: isFadingOut ? 0.5 : charDuration,
                ease: easing,
              }}
              style={{ display: 'inline-block', marginRight: '0.25em' }}
            >
              {word}
            </motion.span>
          ))}
          {indicatorPosition === 'end' && shouldShowIndicator && trailingComponent}
        </div>
      );
    }

    const words = text.split(' ');
    let charIndex = 0;

    return (
      <div className="text-content" style={textStyle}>
        {words.map((word, wIdx) => {
          const wordChars = word.split('');
          return (
            <span key={wIdx} className="inline-block" style={{ whiteSpace: 'nowrap' }}>
              {wordChars.map((char, cIdx) => {
                const i = charIndex++;
                return i < visibleCount ? (
                  <motion.span
                    key={cIdx}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: isFadingOut ? 0 : 1 }}
                    transition={{
                      duration: isFadingOut ? 0.5 : charDuration,
                      ease: easing,
                    }}
                    style={{ display: 'inline-block' }}
                  >
                    {char}
                  </motion.span>
                ) : null;
              })}
              {/* Add space after word if not last */}
              {wIdx < words.length - 1 && charIndex++ < visibleCount ? (
                <span style={{ display: 'inline-block' }}>&nbsp;</span>
              ) : null}
            </span>
          );
        })}
        {indicatorPosition === 'end' && shouldShowIndicator && trailingComponent}
      </div>
    );
  };

  return (
    <div className="text-renderer-container" style={containerStyle}>
      {indicatorPosition === 'above' && shouldShowIndicator && (
        <div style={{ marginBottom: '8px' }}>{trailingComponent}</div>
      )}
      {renderTextContent()}
      {indicatorPosition === 'below' && shouldShowIndicator && (
        <div style={{ marginTop: '8px' }}>{trailingComponent}</div>
      )}
    </div>
  );
}
