import React, { useState, useRef, useEffect } from 'react';

export default function EaseGraph({ value = [0.25, 0.1, 0.25, 1.0], onChange }) {
  const [p1, setP1] = useState({ x: value[0], y: value[1] });
  const [p2, setP2] = useState({ x: value[2], y: value[3] });
  
  const svgRef = useRef(null);
  const [activePoint, setActivePoint] = useState(null);

  const width = 200;
  const height = 200;

  useEffect(() => {
    setP1({ x: value[0], y: value[1] });
    setP2({ x: value[2], y: value[3] });
  }, [value]);

  const toSvgCoords = (p) => ({
    x: p.x * width,
    y: (1 - p.y) * height
  });

  const fromSvgCoords = (e) => {
    const rect = svgRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / width;
    const y = 1 - (e.clientY - rect.top) / height;
    return {
      x: Math.max(0, Math.min(1, x)),
      y: Math.max(0, Math.min(1, y))
    };
  };

  const handleMouseDown = (point) => {
    setActivePoint(point);
  };

  const handleMouseMove = (e) => {
    if (!activePoint) return;
    const p = fromSvgCoords(e);
    if (activePoint === 1) {
      setP1(p);
      onChange([p.x, p.y, p2.x, p2.y]);
    } else if (activePoint === 2) {
      setP2(p);
      onChange([p1.x, p1.y, p.x, p.y]);
    }
  };

  const handleMouseUp = () => {
    setActivePoint(null);
  };

  const s1 = toSvgCoords(p1);
  const s2 = toSvgCoords(p2);

  return (
    <div className="space-y-2 font-sans">
      <label className="text-xs font-medium text-gray-700">Easing (Cubic Bezier)</label>
      <div 
        className="border border-gray-200 rounded-lg overflow-hidden bg-gray-50"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <svg 
          ref={svgRef}
          width={width} 
          height={height} 
          className="cursor-pointer"
        >
          {/* Grid lines */}
          <line x1="0" y1="0" x2={width} y2={height} stroke="#e5e7eb" strokeDasharray="4" />
          <line x1="0" y1={height} x2={width} y2={0} stroke="#e5e7eb" strokeDasharray="4" />
          
          {/* Bezier Curve */}
          <path 
            d={`M 0 ${height} C ${s1.x} ${s1.y}, ${s2.x} ${s2.y}, ${width} 0`} 
            fill="none" 
            stroke="#2563eb" 
            strokeWidth="3" 
          />
          
          {/* Control lines */}
          <line x1="0" y1={height} x2={s1.x} y2={s1.y} stroke="#9ca3af" strokeWidth="1.5" />
          <line x1={width} y1="0" x2={s2.x} y2={s2.y} stroke="#9ca3af" strokeWidth="1.5" />
          
          {/* Control points */}
          <circle 
            cx={s1.x} 
            cy={s1.y} 
            r="7" 
            fill="#ef4444" 
            onMouseDown={() => handleMouseDown(1)} 
            className="cursor-move shadow-sm"
          />
          <circle 
            cx={s2.x} 
            cy={s2.y} 
            r="7" 
            fill="#ef4444" 
            onMouseDown={() => handleMouseDown(2)} 
            className="cursor-move shadow-sm"
          />
        </svg>
      </div>
      <div className="text-xs text-gray-500 font-mono bg-gray-100 p-2 rounded-lg text-center">
        {p1.x.toFixed(2)}, {p1.y.toFixed(2)}, {p2.x.toFixed(2)}, {p2.y.toFixed(2)}
      </div>
    </div>
  );
}
